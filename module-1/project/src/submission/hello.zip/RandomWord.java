import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {
    public static void main(String[] args) {

        String value = StdIn.readString();
        int count_read = 1;
        
        while (!StdIn.isEmpty()) {
            count_read ++;
            String s = StdIn.readString();

            boolean shouldReplace = StdRandom.bernoulli( 1.0 / (double)count_read);

            if (shouldReplace) {
                value = s;
            }
        }

        System.out.println(value);
    }
} 